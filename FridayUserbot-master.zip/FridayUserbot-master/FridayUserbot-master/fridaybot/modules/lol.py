# if u steal credits u wil be the gayest gay in the world. i will fban u from 100 feds and u will leave tg
"""
Pulls Up A Random string created by Indian Bhai.
cmd: .lol
    full credits : @pureindialover
"""
import asyncio
import random

from uniborg.util import friday_on_cmd

from fridaybot import CMD_HELP


@friday.on(friday_on_cmd(pattern=r"lol"))
async def _(event):

    if event.fwd_from:

        return

    await event.edit("Typing...")

    await asyncio.sleep(2)

    x = random.randrange(1, 28)
    if x == 1:
        await event.edit(";l;;o;;l;")
    if x == 2:
        await event.edit("lloll")
    if x == 3:
        await event.edit(";l;o;l;")
    if x == 4:
        await event.edit("lo/;l")
    if x == 5:
        await event.edit("/lol/*")
    if x == 6:
        await event.edit("\lol")
    if x == 7:
        await event.edit("lllolll")
    if x == 8:
        await event.edit("l-o-l")
    if x == 9:
        await event.edit("-l;o;l-")
    if x == 10:
        await event.edit("[lol]")
    if x == 11:
        await event.edit(";;loo;l")
    if x == 12:
        await event.edit("l.o.l")
    if x == 13:
        await event.edit(";l.o.l;")
    if x == 14:
        await event.edit("llooll")
    if x == 15:
        await event.edit("phuck.lol")
    if x == 16:
        await event.edit("/l:o;l.")
    if x == 17:
        await event.edit("ll;oo;lll")
    if x == 18:
        await event.edit("loooooooooooool")
    if x == 19:
        await event.edit("lollll.lll;lol")
    if x == 20:
        await event.edit(";;;llloo;oo;ollll;;")
    if x == 21:
        await event.edit("lol me laughed hehehe")
    if x == 22:
        await event.edit("tum haso ab lol")
    if x == 23:
        await event.edit(":l:o:l:")
    if x == 24:
        await event.edit("l-o+l")
    if x == 25:
        await event.edit("l+o=l")
    if x == 26:
        await event.edit("l|o|l")
    if x == 27:
        await event.edit("hola lol")
    if x == 28:
        await event.edit("llllllllllllllooooooooooollllllllll")


CMD_HELP.update(
    {
        "lol": "**Lol**\
\n\n**Syntax : **`.lol`\
\n**Usage :** Pulls up a random lol string."
    }
)
